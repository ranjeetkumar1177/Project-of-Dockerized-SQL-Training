from flask import Flask, render_template, request
import mysql.connector
import os

app = Flask(__name__)

# --- Database Connection Details ---
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_USER = os.environ.get('DB_USER', 'user')
DB_PASSWORD = os.environ.get('DB_PASSWORD', 'password')
DB_NAME = os.environ.get('DB_NAME', 'school_db')

def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        return conn
    except mysql.connector.Error:
        return None

# --- Page Routes ---

@app.route('/')
def intro_page():
    return render_template('index.html')

@app.route('/schoolHomePage.html')
def school_home():
    return render_template('schoolHomePage.html')

@app.route('/academics.html')
def academics():
    return render_template('academics.html')

@app.route('/admissions.html')
def admissions():
    return render_template('admissions.html')

@app.route('/campus-life.html')
def campus_life():
    return render_template('campus-life.html')

# --- Login Logic Routes ---

@app.route('/student_login', methods=['POST'])
def student_login():
    username = request.form.get('student_username')
    password = request.form.get('student_password')
    message = ""
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor(dictionary=True)
        query = f"SELECT * FROM students WHERE username = '{username}' AND password = '{password}'"
        print(f"Executing Student Query: {query}")
        try:
            cursor.execute(query)
            # --- FIX IS HERE ---
            # Fetch ALL results to clear the buffer
            results = cursor.fetchall() 
            
            if results: # Check if the list of results is not empty
                account = results[0] # Get the first user from the list
                message = f"Student login successful! Welcome, {account['full_name']}."
            else:
                message = "Student login failed. Incorrect credentials."
        except mysql.connector.Error as e:
            message = f"Database Error: {e}"
        finally:
            cursor.close()
            conn.close()
    else:
        message = "Database connection failed."
    return render_template('schoolHomePage.html', student_login_message=message)


@app.route('/faculty_login', methods=['POST'])
def faculty_login():
    email = request.form.get('faculty_username')
    password = request.form.get('faculty_password')
    message = ""
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor(dictionary=True)
        query = f"SELECT * FROM faculty WHERE email = '{email}' AND password = '{password}'"
        print(f"Executing Faculty Query: {query}")
        try:
            cursor.execute(query)
            # --- FIX IS HERE ---
            # Fetch ALL results to clear the buffer
            results = cursor.fetchall() 

            if results: # Check if the list of results is not empty
                account = results[0] # Get the first user from the list
                message = f"Faculty login successful! Welcome, {account['full_name']}."
            else:
                message = "Faculty login failed. Incorrect credentials."
        except mysql.connector.Error as e:
            message = f"Database Error: {e}"
        finally:
            cursor.close()
            conn.close()
    else:
        message = "Database connection failed."
    return render_template('schoolHomePage.html', faculty_login_message=message)

@app.route('/course_lookup', methods=['POST'])
def course_lookup():
    course_id = request.form.get('course_id')
    message = ""
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        query = f"SELECT course_name FROM courses WHERE course_id = '{course_id}'"
        print(f"Executing Course Query: {query}")
        try:
            cursor.execute(query)
            # --- FIX IS HERE ---
            # Fetch ALL results to clear the buffer
            results = cursor.fetchall() 
            
            if results:
                message = "Result: Course Found!"
            else:
                message = "Result: Course Not Found."
        except mysql.connector.Error:
            message = "Result: An error occurred."
        finally:
            cursor.close()
            conn.close()
    else:
        message = "Database connection failed."
    return render_template('academics.html', course_message=message)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)